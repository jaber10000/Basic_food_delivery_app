import 'dart:js';
import "package:flutter/material.dart";
import 'package:provider/provider.dart';
import 'package:t_store/auth/login%20or%20register.dart';
import 'package:t_store/models/restaurant.dart';
import 'package:t_store/pages/register_page.dart';
import 'package:t_store/themes/theme_provider.dart';
import 'pages/login_page.dart';

void main(){
  WidgetsFlutterBinding.ensureInitialized();

  runApp(
      MultiProvider(providers: [
        ChangeNotifierProvider(create: (context) => ThemeProvider()),
        
        ChangeNotifierProvider(create: (context) => Restaurant()),
      ],
      child: const MyApp(),
      ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return  MaterialApp(
      debugShowCheckedModeBanner: false,
      home: const LoginOrRegister(),
      theme: Provider.of<ThemeProvider>(context).themeData,
    );
  }
}